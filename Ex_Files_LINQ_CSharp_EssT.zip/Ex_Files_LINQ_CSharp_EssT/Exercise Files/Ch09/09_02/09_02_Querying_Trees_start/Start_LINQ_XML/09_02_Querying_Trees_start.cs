﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace Start_LINQ_XML
{
    class Start_LINQ_XML
    {

        static void Main(string[] args)
        {
            

            Console.ReadKey();
            
        }
    }
}
